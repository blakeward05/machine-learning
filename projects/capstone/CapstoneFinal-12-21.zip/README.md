# Machine Learning Engineer Nanodegree
## Specializations
## Project: Capstone Proposal and Capstone Project
## Blake Ward

**Note**

This project uses the following standard python libraries for data manipulation:

Pandas
Numpy
Matplotlib

For machine learning it uses sklearn modules.

The data can be found in the project folder as run-time-data.csv

